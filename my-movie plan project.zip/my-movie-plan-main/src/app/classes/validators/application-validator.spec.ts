import { ApplicationValidator } from './application-validator';

describe('ApplicationValidator', () => {
  it('should create an instance', () => {
    expect(new ApplicationValidator()).toBeTruthy();
  });
});
